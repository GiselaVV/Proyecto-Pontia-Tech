¡Bienvenid@!

Si quieres echarle un vistazo a mi proyecto de fin de máster de Pontia, simplemente tienes que entrar en la carpeta "Pontia Bank S.L", donde encontrarás de forma ordenada, todos los archivos ejecutables para ver el trabajo realizado. \
En la carpeta "Definitivo" encontrarás todo tipo de archivos ejecutables necesarios para llevar a cabo el proyecto, pero no son relevantes para el cliente. Aún así, no es conveniente eliminarlos. Todo trabajo realizado es bien visto ;)

Espero que lo disfrutes.
